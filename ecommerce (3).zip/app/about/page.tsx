import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-6">À propos de BAGS & BUCKLES</h1>

        <div className="prose prose-lg max-w-none">
          <div className="mb-12 flex flex-col items-center">
            <div className="w-full max-w-xs sm:max-w-sm md:max-w-md overflow-hidden mb-6">
              <img
                src="/logo.png"
                alt="BAGS & BUCKLES Logo"
                className="h-auto w-full object-contain transition-all duration-300 hover:scale-105 shadow-sm rounded-lg p-4"
              />
            </div>
          </div>

          <h2 className="text-2xl font-semibold mt-8 mb-4">Notre Histoire</h2>
          <p>
            Fondée en 2015, BAGS & BUCKLES est née d'une passion pour les accessoires de mode de qualité. Notre
            fondatrice, après des années d'expérience dans l'industrie de la mode, a décidé de créer une marque qui
            combine l'élégance intemporelle avec la fonctionnalité moderne.
          </p>

          <h2 className="text-2xl font-semibold mt-8 mb-4">Notre Mission</h2>
          <p>
            Chez BAGS & BUCKLES, notre mission est de proposer des accessoires de haute qualité qui allient style,
            durabilité et éthique. Nous croyons que les beaux objets doivent être fabriqués avec soin et respect, tant
            pour les artisans que pour l'environnement.
          </p>

          <h2 className="text-2xl font-semibold mt-8 mb-4">Nos Valeurs</h2>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              <strong>Qualité</strong> - Nous utilisons uniquement les meilleurs matériaux et techniques de fabrication.
            </li>
            <li>
              <strong>Durabilité</strong> - Nos produits sont conçus pour durer et résister à l'épreuve du temps.
            </li>
            <li>
              <strong>Éthique</strong> - Nous travaillons avec des artisans qualifiés et assurons des conditions de
              travail équitables.
            </li>
            <li>
              <strong>Innovation</strong> - Nous recherchons constamment de nouvelles façons d'améliorer nos produits.
            </li>
          </ul>

          <h2 className="text-2xl font-semibold mt-8 mb-4">Notre Engagement</h2>
          <p>
            Nous nous engageons à offrir un service client exceptionnel et à garantir la satisfaction de nos clients.
            Chaque produit BAGS & BUCKLES est soigneusement inspecté avant d'être expédié pour s'assurer qu'il répond à
            nos normes élevées de qualité.
          </p>

          <div className="mt-12 text-center">
            <h3 className="text-xl font-semibold mb-4">Vous avez des questions?</h3>
            <Button asChild className="mt-2">
              <Link href="/contact">Contactez-nous</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
