"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Trash2, ShoppingBag, ArrowRight, Check, X } from "lucide-react"
import { Input } from "@/components/ui/input"
import { toast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  image: string
}

// Liste des codes promo valides
const validPromoCodes = {
  WELCOME10: { discount: 0.1, description: "10% de réduction" },
  SUMMER20: { discount: 0.2, description: "20% de réduction" },
  FREESHIP: { discount: 0, freeShipping: true, description: "Livraison gratuite" },
}

export default function CartPage() {
  const router = useRouter()

  // État initial du panier
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      id: "1",
      name: "T-shirt Premium",
      price: 29.99,
      quantity: 2,
      image: "/plain-white-tshirt.png",
    },
    {
      id: "2",
      name: "Jeans Slim",
      price: 59.99,
      quantity: 1,
      image: "/folded-denim-stack.png",
    },
  ])

  // État pour le code promo
  const [promoCode, setPromoCode] = useState("")
  const [appliedPromo, setAppliedPromo] = useState<{
    code: string
    discount: number
    freeShipping?: boolean
    description: string
  } | null>(null)
  const [promoError, setPromoError] = useState<string | null>(null)

  // État pour le modal de confirmation de commande
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)

  // Calculer le sous-total
  const subtotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
  const standardShipping = 4.99

  // Appliquer la réduction si un code promo est appliqué
  const discount = appliedPromo ? subtotal * (appliedPromo.discount || 0) : 0

  // Déterminer si la livraison est gratuite
  const shipping = appliedPromo?.freeShipping ? 0 : standardShipping

  // Calculer le total final
  const total = subtotal - discount + shipping

  // Fonction pour augmenter la quantité
  const increaseQuantity = (id: string) => {
    setCartItems((prevItems) =>
      prevItems.map((item) => {
        if (item.id === id) {
          return { ...item, quantity: item.quantity + 1 }
        }
        return item
      }),
    )
    toast({
      description: "Quantité mise à jour",
      duration: 2000,
    })
  }

  // Fonction pour diminuer la quantité
  const decreaseQuantity = (id: string) => {
    setCartItems((prevItems) =>
      prevItems.map((item) => {
        if (item.id === id && item.quantity > 1) {
          return { ...item, quantity: item.quantity - 1 }
        }
        return item
      }),
    )
    toast({
      description: "Quantité mise à jour",
      duration: 2000,
    })
  }

  // Fonction pour supprimer un article
  const removeItem = (id: string) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.id !== id))
    toast({
      description: "Article supprimé du panier",
      duration: 2000,
    })
  }

  // Fonction pour appliquer un code promo
  const applyPromoCode = () => {
    // Réinitialiser les erreurs précédentes
    setPromoError(null)

    // Vérifier si le code est vide
    if (!promoCode.trim()) {
      setPromoError("Veuillez entrer un code promo")
      return
    }

    // Vérifier si le code est valide
    const normalizedCode = promoCode.trim().toUpperCase()
    const promoDetails = validPromoCodes[normalizedCode as keyof typeof validPromoCodes]

    if (promoDetails) {
      setAppliedPromo({
        code: normalizedCode,
        ...promoDetails,
      })
      toast({
        description: `Code promo "${normalizedCode}" appliqué avec succès!`,
        duration: 3000,
      })
      setPromoCode("")
    } else {
      setPromoError("Code promo invalide")
      toast({
        variant: "destructive",
        description: "Code promo invalide",
        duration: 3000,
      })
    }
  }

  // Fonction pour retirer un code promo
  const removePromoCode = () => {
    setAppliedPromo(null)
    toast({
      description: "Code promo retiré",
      duration: 2000,
    })
  }

  // Fonction pour gérer le processus de paiement
  const handleCheckout = () => {
    // Vérifier si le panier est vide
    if (cartItems.length === 0) {
      toast({
        variant: "destructive",
        description: "Votre panier est vide",
        duration: 3000,
      })
      return
    }

    // Ouvrir le modal de confirmation
    setIsCheckoutModalOpen(true)
  }

  // Fonction pour finaliser la commande
  const processCheckout = async () => {
    try {
      setIsProcessing(true)

      // Simuler un traitement de commande
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Réinitialiser le panier
      setCartItems([])
      setAppliedPromo(null)
      setIsCheckoutModalOpen(false)

      // Afficher un message de succès
      toast({
        description: "Votre commande a été enregistrée avec succès! Paiement à la livraison.",
        duration: 5000,
      })

      // Rediriger vers une page de confirmation
      router.push("/checkout/success")
    } catch (error) {
      toast({
        variant: "destructive",
        description: "Une erreur est survenue lors de l'enregistrement de votre commande",
        duration: 5000,
      })
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <>
      <div className="container px-4 py-12 md:px-6 md:py-24">
        <h1 className="text-3xl font-bold">Votre Panier</h1>

        {cartItems.length > 0 ? (
          <div className="mt-8 grid gap-8 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <div className="rounded-lg border shadow-sm">
                <div className="p-6">
                  <h2 className="text-xl font-semibold">Articles ({cartItems.length})</h2>
                  <div className="mt-6 divide-y">
                    {cartItems.map((item) => (
                      <div key={item.id} className="flex py-6">
                        <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border">
                          <img
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <div className="ml-4 flex flex-1 flex-col">
                          <div>
                            <div className="flex justify-between text-base font-medium">
                              <h3>{item.name}</h3>
                              <p className="ml-4">{(item.price * item.quantity).toFixed(2)} DH</p>
                            </div>
                            <p className="mt-1 text-sm text-muted-foreground">Quantité: {item.quantity}</p>
                          </div>
                          <div className="flex flex-1 items-end justify-between text-sm">
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-8 w-8 p-0"
                                onClick={() => decreaseQuantity(item.id)}
                                disabled={item.quantity <= 1}
                              >
                                -
                              </Button>
                              <span>{item.quantity}</span>
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-8 w-8 p-0"
                                onClick={() => increaseQuantity(item.id)}
                              >
                                +
                              </Button>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-red-500"
                              onClick={() => removeItem(item.id)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Supprimer
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div>
              <div className="rounded-lg border shadow-sm">
                <div className="p-6">
                  <h2 className="text-xl font-semibold">Résumé de la commande</h2>
                  <div className="mt-6 space-y-4">
                    <div className="flex justify-between">
                      <p>Sous-total</p>
                      <p>{subtotal.toFixed(2)} DH</p>
                    </div>

                    {appliedPromo && appliedPromo.discount > 0 && (
                      <div className="flex justify-between text-green-600">
                        <p>Réduction ({appliedPromo.description})</p>
                        <p>-{discount.toFixed(2)} DH</p>
                      </div>
                    )}

                    <div className="flex justify-between">
                      <p>Frais de livraison</p>
                      <p>{shipping === 0 ? "Gratuit" : `${shipping.toFixed(2)} DH`}</p>
                    </div>

                    <div className="flex justify-between border-t pt-4 font-semibold">
                      <p>Total</p>
                      <p>{total.toFixed(2)} DH</p>
                    </div>
                  </div>

                  <div className="mt-6 space-y-4">
                    {appliedPromo ? (
                      <div className="rounded-md border border-green-200 bg-green-50 p-3 dark:bg-green-950 dark:border-green-800">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center">
                            <Check className="h-4 w-4 text-green-600 mr-2" />
                            <span className="text-sm font-medium">
                              Code <span className="font-bold">{appliedPromo.code}</span> appliqué:{" "}
                              {appliedPromo.description}
                            </span>
                          </div>
                          <Button variant="ghost" size="sm" onClick={removePromoCode}>
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex items-center gap-2">
                          <Input
                            placeholder="Code promo"
                            value={promoCode}
                            onChange={(e) => setPromoCode(e.target.value)}
                            onKeyDown={(e) => e.key === "Enter" && applyPromoCode()}
                          />
                          <Button variant="outline" onClick={applyPromoCode}>
                            Appliquer
                          </Button>
                        </div>
                        {promoError && <p className="text-sm text-red-500">{promoError}</p>}
                        <div className="text-xs text-muted-foreground">
                          <p>Codes promo disponibles pour test:</p>
                          <ul className="list-disc pl-4 mt-1">
                            <li>WELCOME10: 10% de réduction</li>
                            <li>SUMMER20: 20% de réduction</li>
                            <li>FREESHIP: Livraison gratuite</li>
                          </ul>
                        </div>
                      </>
                    )}

                    <Button className="w-full bg-[#0a3277] hover:bg-[#0a3277]/90" onClick={handleCheckout}>
                      Passer à la caisse
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>

                    <div className="text-center text-sm text-muted-foreground">
                      ou{" "}
                      <Link href="/products" className="font-medium text-primary hover:underline">
                        Continuer vos achats
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="mt-8 flex flex-col items-center justify-center rounded-lg border py-12">
            <ShoppingBag className="h-16 w-16 text-muted-foreground" />
            <h2 className="mt-4 text-xl font-semibold">Votre panier est vide</h2>
            <p className="mt-2 text-muted-foreground">Vous n'avez pas encore ajouté d'articles à votre panier.</p>
            <Button className="mt-6" asChild>
              <Link href="/products">Découvrir nos produits</Link>
            </Button>
          </div>
        )}
      </div>

      {/* Modal de confirmation de commande */}
      <Dialog open={isCheckoutModalOpen} onOpenChange={setIsCheckoutModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmer votre commande</DialogTitle>
            <DialogDescription>
              Vous êtes sur le point de finaliser votre commande pour un total de {total.toFixed(2)} DH. Le paiement
              s'effectuera à la livraison.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <h4 className="font-medium">Récapitulatif de votre commande</h4>
              <ul className="space-y-2 text-sm">
                {cartItems.map((item) => (
                  <li key={item.id} className="flex justify-between">
                    <span>
                      {item.name} x {item.quantity}
                    </span>
                    <span>{(item.price * item.quantity).toFixed(2)} DH</span>
                  </li>
                ))}
              </ul>

              <div className="border-t mt-4 pt-4">
                <div className="flex justify-between font-medium">
                  <span>Total</span>
                  <span>{total.toFixed(2)} DH</span>
                </div>
                {appliedPromo && <p className="text-xs text-green-600 mt-1">{appliedPromo.description} appliquée</p>}
              </div>
            </div>
          </div>

          <DialogFooter className="flex flex-col sm:flex-row sm:justify-between">
            <Button variant="outline" onClick={() => setIsCheckoutModalOpen(false)} disabled={isProcessing}>
              Annuler
            </Button>
            <Button onClick={processCheckout} className="bg-[#0a3277] hover:bg-[#0a3277]/90" disabled={isProcessing}>
              {isProcessing ? "Traitement en cours..." : "Passer votre commande"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
