import Link from "next/link"
import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"

export default function CheckoutSuccessPage() {
  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <div className="max-w-md mx-auto text-center">
        <div className="flex justify-center mb-6">
          <div className="rounded-full bg-green-100 p-3 dark:bg-green-900">
            <CheckCircle className="h-12 w-12 text-green-600 dark:text-green-400" />
          </div>
        </div>

        <h1 className="text-3xl font-bold tracking-tighter mb-4">Commande confirmée!</h1>

        <p className="text-muted-foreground mb-8">
          Merci pour votre commande. Votre commande a été enregistrée avec succès et sera expédiée prochainement. Le
          paiement s'effectuera à la livraison.
        </p>

        <div className="bg-muted/50 rounded-lg p-6 mb-8">
          <h2 className="font-semibold mb-2">Détails de la commande</h2>
          <p className="text-sm text-muted-foreground mb-2">
            Numéro de commande: #BNB{Math.floor(100000 + Math.random() * 900000)}
          </p>
          <p className="text-sm text-muted-foreground mb-2">Mode de paiement: Paiement à la livraison</p>
          <p className="text-sm text-muted-foreground">
            Un email de confirmation a été envoyé à votre adresse email avec tous les détails de votre commande.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild variant="outline">
            <Link href="/">Retour à l'accueil</Link>
          </Button>
          <Button asChild className="bg-[#0a3277] hover:bg-[#0a3277]/90">
            <Link href="/products">Continuer vos achats</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
