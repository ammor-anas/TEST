export default function CookiesPage() {
  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-6">Politique de cookies</h1>

        <div className="prose prose-lg max-w-none">
          <p className="lead">
            Dernière mise à jour :{" "}
            {new Date().toLocaleDateString("fr-FR", { year: "numeric", month: "long", day: "numeric" })}
          </p>

          <h2>1. Qu'est-ce qu'un cookie ?</h2>
          <p>
            Un cookie est un petit fichier texte qui est stocké sur votre ordinateur ou appareil mobile lorsque vous
            visitez un site web. Les cookies sont largement utilisés pour faire fonctionner les sites web ou les rendre
            plus efficaces, ainsi que pour fournir des informations aux propriétaires du site.
          </p>

          <h2>2. Comment nous utilisons les cookies</h2>
          <p>Notre site web utilise des cookies pour diverses raisons, notamment pour :</p>
          <ul>
            <li>Faire fonctionner notre site web correctement</li>
            <li>Comprendre comment vous utilisez notre site web</li>
            <li>Améliorer votre expérience sur notre site</li>
            <li>Vous montrer du contenu pertinent pour vous</li>
            <li>Vous montrer des produits que vous avez consultés précédemment</li>
          </ul>

          <h2>3. Types de cookies que nous utilisons</h2>
          <p>Nous utilisons les types de cookies suivants :</p>

          <h3>Cookies strictement nécessaires</h3>
          <p>
            Ces cookies sont essentiels pour vous permettre de naviguer sur notre site web et d'utiliser ses
            fonctionnalités. Sans ces cookies, les services que vous avez demandés, comme la mémorisation de vos
            informations de connexion ou les articles dans votre panier, ne peuvent pas être fournis.
          </p>

          <h3>Cookies de performance</h3>
          <p>
            Ces cookies collectent des informations sur la façon dont les visiteurs utilisent notre site web, par
            exemple quelles pages ils visitent le plus souvent et s'ils reçoivent des messages d'erreur. Ces cookies ne
            collectent pas d'informations qui identifient un visiteur. Toutes les informations que ces cookies
            collectent sont agrégées et donc anonymes. Elles sont uniquement utilisées pour améliorer le fonctionnement
            de notre site web.
          </p>

          <h3>Cookies de fonctionnalité</h3>
          <p>
            Ces cookies permettent à notre site web de se souvenir des choix que vous faites (comme votre nom
            d'utilisateur, votre langue ou la région dans laquelle vous vous trouvez) et de fournir des fonctionnalités
            améliorées et plus personnelles. Ces cookies peuvent également être utilisés pour mémoriser les
            modifications que vous avez apportées à la taille du texte, aux polices et à d'autres parties des pages web
            que vous pouvez personnaliser.
          </p>

          <h3>Cookies de ciblage ou publicitaires</h3>
          <p>
            Ces cookies sont utilisés pour diffuser des publicités plus pertinentes pour vous et vos intérêts. Ils sont
            également utilisés pour limiter le nombre de fois que vous voyez une publicité ainsi que pour aider à
            mesurer l'efficacité des campagnes publicitaires. Ils sont généralement placés par des réseaux publicitaires
            avec notre permission. Ils se souviennent que vous avez visité un site web et cette information est partagée
            avec d'autres organisations telles que les annonceurs.
          </p>

          <h2>4. Contrôle des cookies</h2>
          <p>
            Vous pouvez contrôler et/ou supprimer les cookies comme vous le souhaitez. Vous pouvez supprimer tous les
            cookies qui sont déjà sur votre ordinateur et vous pouvez configurer la plupart des navigateurs pour les
            empêcher d'être placés. Toutefois, si vous le faites, vous devrez peut-être ajuster manuellement certaines
            préférences chaque fois que vous visitez un site, et certains services et fonctionnalités peuvent ne pas
            fonctionner.
          </p>
          <p>
            Pour plus d'informations sur la façon de gérer les cookies dans votre navigateur, veuillez consulter les
            liens suivants :
          </p>
          <ul>
            <li>
              <a href="https://support.google.com/chrome/answer/95647" target="_blank" rel="noopener noreferrer">
                Google Chrome
              </a>
            </li>
            <li>
              <a
                href="https://support.mozilla.org/fr/kb/cookies-informations-sites-enregistrent"
                target="_blank"
                rel="noopener noreferrer"
              >
                Mozilla Firefox
              </a>
            </li>
            <li>
              <a
                href="https://support.microsoft.com/fr-fr/microsoft-edge/supprimer-les-cookies-dans-microsoft-edge-63947406-40ac-c3b8-57b9-2a946a29ae09"
                target="_blank"
                rel="noopener noreferrer"
              >
                Microsoft Edge
              </a>
            </li>
            <li>
              <a
                href="https://support.apple.com/fr-fr/guide/safari/sfri11471/mac"
                target="_blank"
                rel="noopener noreferrer"
              >
                Safari
              </a>
            </li>
          </ul>

          <h2>5. Cookies tiers</h2>
          <p>
            Certains cookies sont placés par des services tiers qui apparaissent sur nos pages. Nous n'avons pas le
            contrôle de ces cookies. Ces tiers peuvent inclure, par exemple, des plateformes de médias sociaux, des
            services d'analyse et des réseaux publicitaires.
          </p>

          <h2>6. Modifications de notre politique de cookies</h2>
          <p>
            Nous pouvons mettre à jour cette politique de cookies de temps à autre. Nous vous encourageons à consulter
            régulièrement cette page pour rester informé des changements.
          </p>

          <h2>7. Contact</h2>
          <p>Si vous avez des questions concernant notre utilisation des cookies, veuillez nous contacter à :</p>
          <p>
            Email : privacy@bagsandbuckles.com
            <br />
            Adresse : 123 Avenue Mohammed V, Casablanca, Maroc
          </p>
        </div>
      </div>
    </div>
  )
}
