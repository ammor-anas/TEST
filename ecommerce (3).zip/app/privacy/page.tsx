export default function PrivacyPage() {
  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-6">
          Politique de confidentialité
        </h1>

        <div className="prose prose-lg max-w-none">
          <p className="lead">
            Dernière mise à jour :{" "}
            {new Date().toLocaleDateString("fr-FR", { year: "numeric", month: "long", day: "numeric" })}
          </p>

          <h2>1. Introduction</h2>
          <p>
            Chez BAGS & BUCKLES, nous nous engageons à protéger votre vie privée. Cette politique de confidentialité
            explique comment nous collectons, utilisons, divulguons et protégeons vos informations personnelles lorsque
            vous visitez notre site web ou effectuez des achats auprès de nous.
          </p>

          <h2>2. Informations que nous collectons</h2>
          <p>Nous pouvons collecter les types d'informations suivants :</p>
          <ul>
            <li>
              <strong>Informations personnelles</strong> : nom, adresse e-mail, numéro de téléphone, adresse postale,
              informations de paiement.
            </li>
            <li>
              <strong>Informations de navigation</strong> : adresse IP, type de navigateur, pages visitées, temps passé
              sur le site.
            </li>
            <li>
              <strong>Informations sur l'appareil</strong> : type d'appareil, système d'exploitation, identifiants
              uniques.
            </li>
            <li>
              <strong>Informations de transaction</strong> : produits achetés, montant dépensé, méthode de paiement.
            </li>
          </ul>

          <h2>3. Comment nous utilisons vos informations</h2>
          <p>Nous utilisons vos informations personnelles pour :</p>
          <ul>
            <li>Traiter vos commandes et paiements</li>
            <li>Vous fournir des informations sur nos produits et services</li>
            <li>Améliorer notre site web et nos services</li>
            <li>Personnaliser votre expérience sur notre site</li>
            <li>Communiquer avec vous concernant votre compte ou vos commandes</li>
            <li>Vous envoyer des communications marketing (avec votre consentement)</li>
            <li>Se conformer à nos obligations légales</li>
          </ul>

          <h2>4. Partage de vos informations</h2>
          <p>Nous pouvons partager vos informations personnelles avec :</p>
          <ul>
            <li>
              <strong>Prestataires de services</strong> : sociétés qui nous aident à exploiter notre site web, à traiter
              les paiements, à livrer les commandes, etc.
            </li>
            <li>
              <strong>Partenaires commerciaux</strong> : entreprises avec lesquelles nous collaborons pour offrir des
              produits ou services conjoints.
            </li>
            <li>
              <strong>Autorités légales</strong> : lorsque nous sommes légalement tenus de le faire ou pour protéger nos
              droits légaux.
            </li>
          </ul>
          <p>Nous ne vendons pas vos informations personnelles à des tiers.</p>

          <h2>5. Sécurité des données</h2>
          <p>
            Nous mettons en œuvre des mesures de sécurité appropriées pour protéger vos informations personnelles contre
            l'accès non autorisé, l'altération, la divulgation ou la destruction. Cependant, aucune méthode de
            transmission sur Internet ou de stockage électronique n'est totalement sécurisée, et nous ne pouvons
            garantir une sécurité absolue.
          </p>

          <h2>6. Cookies et technologies similaires</h2>
          <p>
            Nous utilisons des cookies et des technologies similaires pour améliorer votre expérience sur notre site,
            analyser comment les utilisateurs naviguent sur notre site et personnaliser le contenu. Vous pouvez
            configurer votre navigateur pour refuser tous les cookies ou pour vous avertir lorsqu'un cookie est envoyé.
            Cependant, certaines fonctionnalités de notre site peuvent ne pas fonctionner correctement sans cookies.
          </p>

          <h2>7. Vos droits</h2>
          <p>
            Selon votre lieu de résidence, vous pouvez avoir certains droits concernant vos informations personnelles,
            notamment :
          </p>
          <ul>
            <li>Le droit d'accéder à vos informations personnelles</li>
            <li>Le droit de rectifier des informations inexactes</li>
            <li>Le droit de supprimer vos informations personnelles</li>
            <li>Le droit de restreindre le traitement de vos informations</li>
            <li>Le droit à la portabilité des données</li>
            <li>Le droit de vous opposer au traitement de vos informations</li>
          </ul>
          <p>Pour exercer ces droits, veuillez nous contacter à l'adresse indiquée ci-dessous.</p>

          <h2>8. Conservation des données</h2>
          <p>
            Nous conservons vos informations personnelles aussi longtemps que nécessaire pour atteindre les objectifs
            décrits dans cette politique de confidentialité, sauf si une période de conservation plus longue est requise
            ou permise par la loi.
          </p>

          <h2>9. Modifications de cette politique</h2>
          <p>
            Nous pouvons mettre à jour cette politique de confidentialité de temps à autre. La version la plus récente
            sera publiée sur cette page, et la date de la dernière mise à jour sera modifiée en conséquence.
          </p>

          <h2>10. Contact</h2>
          <p>Si vous avez des questions concernant cette politique de confidentialité, veuillez nous contacter à :</p>
          <p>
            Email : privacy@bagsandbuckles.com
            <br />
            Adresse : 123 Avenue Mohammed V, Casablanca, Maroc
          </p>
        </div>
      </div>
    </div>
  )
}
