import { products } from "@/lib/products"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Heart, Share2 } from "lucide-react"
import { notFound } from "next/navigation"
import ProductCard from "@/components/product-card"

interface ProductPageProps {
  params: {
    id: string
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  const product = products.find((p) => p.id === params.id)

  if (!product) {
    notFound()
  }

  const relatedProducts = products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4)

  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <div className="grid gap-8 md:grid-cols-2">
        <div className="overflow-hidden rounded-lg">
          <img src={product.image || "/placeholder.svg"} alt={product.name} className="h-full w-full object-cover" />
        </div>
        <div className="flex flex-col gap-4">
          <h1 className="text-3xl font-bold">{product.name}</h1>
          <div className="flex items-center gap-2">
            <div className="text-sm text-yellow-500">★★★★★</div>
            <span className="text-sm text-muted-foreground">(12 avis)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold">{product.price} DH</span>
            {product.oldPrice && (
              <span className="text-lg text-muted-foreground line-through">{product.oldPrice} DH</span>
            )}
          </div>
          <p className="text-muted-foreground">{product.description}</p>

          <div className="mt-4 space-y-4">
            <div className="flex flex-col gap-2">
              <span className="font-medium">Couleur</span>
              <div className="flex gap-2">
                {["bg-red-500", "bg-blue-500", "bg-green-500", "bg-yellow-500"].map((color, i) => (
                  <div
                    key={i}
                    className={`h-8 w-8 rounded-full ${color} cursor-pointer ring-offset-2 ring-offset-background transition-all hover:ring-2 hover:ring-primary`}
                  />
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <span className="font-medium">Taille</span>
              <div className="flex flex-wrap gap-2">
                {["S", "M", "L", "XL"].map((size) => (
                  <Button key={size} variant="outline" className="h-10 w-10 p-0">
                    {size}
                  </Button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <span className="font-medium">Quantité</span>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" className="h-10 w-10 p-0">
                  -
                </Button>
                <span className="w-10 text-center">1</span>
                <Button variant="outline" size="icon" className="h-10 w-10 p-0">
                  +
                </Button>
              </div>
            </div>
          </div>

          <div className="mt-6 flex gap-4">
            <Button className="flex-1">
              <ShoppingCart className="mr-2 h-4 w-4" />
              Ajouter au panier
            </Button>
            <Button variant="outline" size="icon">
              <Heart className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon">
              <Share2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="mt-16">
          <h2 className="text-2xl font-bold">Produits similaires</h2>
          <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {relatedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
