import { products } from "@/lib/products"
import ProductCard from "@/components/product-card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ChevronLeft } from "lucide-react"

export default function CeinturesPage() {
  // Filtrer les produits pour n'afficher que les ceintures
  const ceintures = products.filter((product) => product.category === "ceintures")

  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <div className="flex flex-col items-start gap-4 md:flex-row md:justify-between md:gap-8">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Link href="/products" className="flex items-center text-sm text-muted-foreground hover:text-foreground">
              <ChevronLeft className="h-4 w-4" />
              Retour aux produits
            </Link>
          </div>
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Ceintures</h1>
          <p className="mt-2 text-gray-500 md:text-xl">Explorez notre sélection de ceintures élégantes et durables.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">Filtrer</Button>
          <Button variant="outline">Trier</Button>
        </div>
      </div>

      {ceintures.length > 0 ? (
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {ceintures.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="mt-8 flex flex-col items-center justify-center py-12 text-center">
          <p className="text-lg text-muted-foreground">Aucun produit trouvé dans cette catégorie.</p>
          <Button asChild className="mt-4">
            <Link href="/products">Voir tous les produits</Link>
          </Button>
        </div>
      )}
    </div>
  )
}
