import { products } from "@/lib/products"
import ProductCard from "@/components/product-card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function ProductsPage() {
  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <div className="flex flex-col items-start gap-4 md:flex-row md:justify-between md:gap-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Tous les produits</h1>
          <p className="mt-2 text-gray-500 md:text-xl">Découvrez notre gamme complète de produits.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">Filtrer</Button>
          <Button variant="outline">Trier</Button>
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Catégories</h2>
        <div className="flex flex-wrap gap-2">
          <Button asChild variant="outline">
            <Link href="/products">Tous</Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/products/sacs-a-main">Sacs à main</Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/products/ceintures">Ceintures</Link>
          </Button>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  )
}
