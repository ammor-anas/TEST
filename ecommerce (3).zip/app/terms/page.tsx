export default function TermsPage() {
  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-6">Conditions d'utilisation</h1>

        <div className="prose prose-lg max-w-none">
          <p className="lead">
            Dernière mise à jour :{" "}
            {new Date().toLocaleDateString("fr-FR", { year: "numeric", month: "long", day: "numeric" })}
          </p>

          <h2>1. Introduction</h2>
          <p>
            Bienvenue sur le site web de BAGS & BUCKLES. Les présentes conditions d'utilisation régissent votre
            utilisation de notre site web et de tous les services associés. En accédant à notre site ou en utilisant nos
            services, vous acceptez d'être lié par ces conditions. Si vous n'acceptez pas ces conditions, veuillez ne
            pas utiliser notre site.
          </p>

          <h2>2. Définitions</h2>
          <p>Dans les présentes conditions d'utilisation, les termes suivants auront les significations suivantes :</p>
          <ul>
            <li>"Nous", "notre", "nos" désignent BAGS & BUCKLES.</li>
            <li>"Vous", "votre", "vos" désignent l'utilisateur ou le visiteur de notre site web.</li>
            <li>"Site" désigne le site web de BAGS & BUCKLES accessible à l'adresse [www.bagsandbuckles.com].</li>
            <li>
              "Services" désigne tous les produits, services, contenus, fonctionnalités et applications proposés par
              BAGS & BUCKLES.
            </li>
          </ul>

          <h2>3. Utilisation du site</h2>
          <p>
            Vous acceptez d'utiliser notre site uniquement à des fins légales et d'une manière qui ne porte pas atteinte
            aux droits d'autrui, ne restreint pas ou n'empêche pas l'utilisation et la jouissance du site par quiconque.
            Vous ne devez pas utiliser notre site d'une manière qui pourrait endommager, désactiver, surcharger ou
            compromettre notre site ou interférer avec l'utilisation du site par d'autres parties.
          </p>

          <h2>4. Compte utilisateur</h2>
          <p>
            Pour accéder à certaines fonctionnalités de notre site, vous devrez peut-être créer un compte. Vous êtes
            responsable du maintien de la confidentialité de vos informations de compte, y compris votre mot de passe,
            et de toutes les activités qui se produisent sous votre compte. Vous acceptez de nous informer immédiatement
            de toute utilisation non autorisée de votre compte ou de toute autre violation de la sécurité.
          </p>

          <h2>5. Propriété intellectuelle</h2>
          <p>
            Le contenu de notre site, y compris, mais sans s'y limiter, les textes, graphiques, logos, icônes, images,
            clips audio, téléchargements numériques et compilations de données, est la propriété de BAGS & BUCKLES ou de
            ses fournisseurs de contenu et est protégé par les lois marocaines et internationales sur le droit d'auteur.
            La compilation de tout le contenu de notre site est la propriété exclusive de BAGS & BUCKLES et est protégée
            par les lois marocaines et internationales sur le droit d'auteur.
          </p>

          <h2>6. Produits et services</h2>
          <p>
            Tous les produits et services proposés sur notre site sont soumis à disponibilité. Nous nous réservons le
            droit de limiter les quantités de produits achetés par personne, par foyer ou par commande. Nous nous
            réservons le droit de refuser les commandes, de mettre fin aux comptes ou d'annuler les commandes à notre
            seule discrétion.
          </p>

          <h2>7. Prix et paiements</h2>
          <p>
            Tous les prix affichés sur notre site sont en dirhams marocains (DH) et incluent la TVA applicable. Nous
            nous réservons le droit de modifier les prix à tout moment. Les paiements peuvent être effectués par les
            méthodes indiquées sur notre site au moment de l'achat.
          </p>

          <h2>8. Livraison</h2>
          <p>
            Nous livrons nos produits au Maroc et dans certains pays internationaux. Les délais de livraison sont
            fournis à titre indicatif uniquement et peuvent varier. Nous ne sommes pas responsables des retards de
            livraison causés par des circonstances indépendantes de notre volonté.
          </p>

          <h2>9. Retours et remboursements</h2>
          <p>
            Vous pouvez retourner les produits achetés sur notre site dans les 14 jours suivant la réception, à
            condition qu'ils soient dans leur état d'origine, non utilisés et dans leur emballage d'origine. Les frais
            de retour sont à votre charge, sauf si le produit est défectueux ou incorrect.
          </p>

          <h2>10. Limitation de responsabilité</h2>
          <p>
            Dans toute la mesure permise par la loi, BAGS & BUCKLES ne sera pas responsable des dommages directs,
            indirects, accessoires, spéciaux ou consécutifs résultant de l'utilisation ou de l'impossibilité d'utiliser
            notre site ou nos services.
          </p>

          <h2>11. Modifications des conditions</h2>
          <p>
            Nous nous réservons le droit de modifier ces conditions d'utilisation à tout moment. Les modifications
            entreront en vigueur dès leur publication sur notre site. Votre utilisation continue de notre site après la
            publication des modifications constitue votre acceptation de ces modifications.
          </p>

          <h2>12. Loi applicable</h2>
          <p>
            Les présentes conditions d'utilisation sont régies par les lois du Maroc. Tout litige découlant de ces
            conditions sera soumis à la juridiction exclusive des tribunaux marocains.
          </p>

          <h2>13. Contact</h2>
          <p>
            Si vous avez des questions concernant ces conditions d'utilisation, veuillez nous contacter à l'adresse
            suivante : contact@bagsandbuckles.com
          </p>
        </div>
      </div>
    </div>
  )
}
