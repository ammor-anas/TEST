import type { Product } from "@/lib/types"
import ProductCard from "./product-card"

interface FeaturedSectionProps {
  products: Product[]
}

export default function FeaturedSection({ products }: FeaturedSectionProps) {
  return (
    <section className="w-full py-12 md:py-24">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Produits à la une</h2>
            <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
              Découvrez notre sélection de produits populaires.
            </p>
          </div>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
