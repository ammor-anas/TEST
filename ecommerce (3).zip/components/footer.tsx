import Link from "next/link"

export default function Footer() {
  return (
    <footer className="w-full border-t bg-background py-6 md:py-10">
      <div className="container flex flex-col md:flex-row justify-between gap-8">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="BAGS & BUCKLES Logo" className="h-8 w-auto" />
            <h3 className="text-lg font-semibold text-[#0a3277]">BAGS & BUCKLES</h3>
          </div>
          <p className="text-sm text-muted-foreground max-w-xs">
            Votre boutique en ligne de produits élégants et de qualité.
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="flex flex-col gap-2">
            <h4 className="text-sm font-semibold">Navigation</h4>
            <nav className="flex flex-col gap-2">
              <Link href="/" className="text-sm text-muted-foreground hover:text-foreground">
                Accueil
              </Link>
              <Link href="/products" className="text-sm text-muted-foreground hover:text-foreground">
                Produits
              </Link>
              <Link href="/categories" className="text-sm text-muted-foreground hover:text-foreground">
                Catégories
              </Link>
            </nav>
          </div>
          <div className="flex flex-col gap-2">
            <h4 className="text-sm font-semibold">À propos</h4>
            <nav className="flex flex-col gap-2">
              <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground">
                Notre histoire
              </Link>
              <Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground">
                Contact
              </Link>
              <Link href="/faq" className="text-sm text-muted-foreground hover:text-foreground">
                FAQ
              </Link>
            </nav>
          </div>
          <div className="flex flex-col gap-2">
            <h4 className="text-sm font-semibold">Légal</h4>
            <nav className="flex flex-col gap-2">
              <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground">
                Conditions d'utilisation
              </Link>
              <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground">
                Politique de confidentialité
              </Link>
              <Link href="/cookies" className="text-sm text-muted-foreground hover:text-foreground">
                Cookies
              </Link>
            </nav>
          </div>
          <div className="flex flex-col gap-2">
            <h4 className="text-sm font-semibold">Suivez-nous</h4>
            <nav className="flex flex-col gap-2">
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Facebook
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Instagram
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Twitter
              </Link>
            </nav>
          </div>
        </div>
      </div>
      <div className="container mt-8 border-t pt-4">
        <p className="text-xs text-center text-muted-foreground">
          © {new Date().getFullYear()} BAGS & BUCKLES. Tous droits réservés.
        </p>
      </div>
    </footer>
  )
}
