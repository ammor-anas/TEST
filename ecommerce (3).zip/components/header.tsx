"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Menu, ShoppingCart, Sun, Moon, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useTheme } from "next-themes"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export default function Header() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  // Effet pour s'assurer que le rendu côté client est terminé avant d'accéder au thème
  useEffect(() => {
    setMounted(true)
  }, [])

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[240px] sm:w-[300px]">
              <nav className="flex flex-col gap-4 mt-8">
                <Link
                  href="/"
                  className="text-lg font-medium transition-colors hover:text-primary"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Accueil
                </Link>
                <Link
                  href="/products"
                  className="text-lg font-medium transition-colors hover:text-primary"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Produits
                </Link>
                <Link
                  href="/categories"
                  className="text-lg font-medium transition-colors hover:text-primary"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Catégories
                </Link>
                <Link
                  href="/products/sacs-a-main"
                  className="text-lg font-medium transition-colors hover:text-primary pl-4 border-l-2 border-gray-200"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Sacs à main
                </Link>
                <Link
                  href="/products/ceintures"
                  className="text-lg font-medium transition-colors hover:text-primary pl-4 border-l-2 border-gray-200"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Ceintures
                </Link>
                <Link
                  href="/about"
                  className="text-lg font-medium transition-colors hover:text-primary"
                  onClick={() => setIsMenuOpen(false)}
                >
                  À propos
                </Link>
                <Link
                  href="/contact"
                  className="text-lg font-medium transition-colors hover:text-primary"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Contact
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
          <Link href="/" className="flex items-center space-x-2">
            <img src="/logo.png" alt="BAGS & BUCKLES Logo" className="h-10 w-auto" />
            <span className="hidden md:inline-block text-xl font-bold text-[#0a3277]">BAGS & BUCKLES</span>
          </Link>
        </div>
        <nav className="hidden md:flex items-center gap-6">
          <Link href="/" className="text-sm font-medium transition-colors hover:text-primary">
            Accueil
          </Link>
          <Link href="/products" className="text-sm font-medium transition-colors hover:text-primary">
            Produits
          </Link>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Link
                href="/categories"
                className="flex items-center text-sm font-medium transition-colors hover:text-primary"
              >
                Catégories <ChevronDown className="ml-1 h-4 w-4" />
              </Link>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem>
                <Link href="/products/sacs-a-main" className="w-full">
                  Sacs à main
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Link href="/products/ceintures" className="w-full">
                  Ceintures
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Link href="/categories" className="w-full">
                  Toutes les catégories
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Link href="/about" className="text-sm font-medium transition-colors hover:text-primary">
            À propos
          </Link>
          <Link href="/contact" className="text-sm font-medium transition-colors hover:text-primary">
            Contact
          </Link>
        </nav>
        <div className="flex items-center gap-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  aria-label="Changer de thème"
                  onClick={toggleTheme}
                  className="relative overflow-hidden transition-all duration-300 hover:bg-primary hover:text-primary-foreground"
                >
                  {mounted && (
                    <>
                      <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                      <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                    </>
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{theme === "dark" ? "Passer au mode clair" : "Passer au mode sombre"}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <Link href="/cart">
            <Button variant="ghost" size="icon" className="relative">
              <ShoppingCart className="h-5 w-5" />
              <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs">0</Badge>
              <span className="sr-only">Panier</span>
            </Button>
          </Link>
        </div>
      </div>
    </header>
  )
}
