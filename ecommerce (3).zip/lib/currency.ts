/**
 * Formatte un prix en dirhams marocains
 * @param price - Le prix à formater
 * @returns Le prix formaté avec le symbole DH
 */
export function formatPrice(price: number): string {
  return `${price.toFixed(2)} DH`
}

/**
 * Calcule le total d'un panier
 * @param items - Les articles du panier avec leur prix et quantité
 * @returns Le total calculé
 */
export function calculateTotal(items: Array<{ price: number; quantity: number }>): number {
  return items.reduce((total, item) => total + item.price * item.quantity, 0)
}
