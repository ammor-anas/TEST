import type { Product, Category } from "./types"

export const products: Product[] = [
  {
    id: "1",
    name: "Sac à main Premium",
    description: "Sac à main en cuir véritable de haute qualité, élégant et spacieux.",
    price: 1299.99,
    oldPrice: 1599.99,
    image: "/colorful-backpack-on-wooden-table.png",
    category: "sacs-a-main",
    featured: true,
  },
  {
    id: "2",
    name: "Sac bandoulière Chic",
    description: "Sac bandoulière compact et élégant pour un style décontracté.",
    price: 799.99,
    image: "/colorful-backpack-on-wooden-table.png",
    category: "sacs-a-main",
  },
  {
    id: "3",
    name: "Ceinture Classique",
    description: "Ceinture en cuir véritable avec boucle élégante, un classique intemporel.",
    price: 499.99,
    oldPrice: 599.99,
    image: "/stylish-sunglasses.png",
    category: "ceintures",
    featured: true,
  },
  {
    id: "4",
    name: "Sac à dos Aventure",
    description: "Sac à dos spacieux et résistant pour toutes vos aventures.",
    price: 499.99,
    image: "/colorful-backpack-on-wooden-table.png",
    category: "sacs-a-main",
  },
  {
    id: "5",
    name: "Ceinture Tressée",
    description: "Ceinture tressée en cuir véritable, parfaite pour un look casual chic.",
    price: 399.99,
    oldPrice: 499.99,
    image: "/stylish-sunglasses.png",
    category: "ceintures",
  },
  {
    id: "6",
    name: "Sac de soirée Élégance",
    description: "Petit sac de soirée élégant avec chaîne dorée, parfait pour vos événements.",
    price: 899.99,
    image: "/colorful-backpack-on-wooden-table.png",
    category: "sacs-a-main",
  },
  {
    id: "7",
    name: "Ceinture Large Fashion",
    description: "Ceinture large en cuir avec boucle design, pour un look affirmé.",
    price: 599.99,
    image: "/stylish-sunglasses.png",
    category: "ceintures",
  },
  {
    id: "8",
    name: "Sac Hobo Casual",
    description: "Sac hobo en cuir souple, idéal pour un usage quotidien décontracté.",
    price: 999.99,
    image: "/colorful-backpack-on-wooden-table.png",
    category: "sacs-a-main",
  },
]

export const categories: Category[] = [
  {
    id: "sacs-a-main",
    name: "Sacs à main",
    image: "/colorful-backpack-on-wooden-table.png",
  },
  {
    id: "ceintures",
    name: "Ceintures",
    image: "/stylish-sunglasses.png",
  },
  {
    id: "accessoires",
    name: "Accessoires",
    image: "/fashion-accessories-flatlay.png",
  },
  {
    id: "nouveautes",
    name: "Nouveautés",
    image: "/diverse-group-playing-various-sports.png",
  },
]
